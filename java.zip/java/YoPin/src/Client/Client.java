/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Client;

/**
 *
 * @author zhuqihao
 */
public class Client {

	/**
	 * 起始函数，调用登录界面
	 */
	public static void main(String[] args) {
		new LoginClient();
	}

}
