package Community;

// 保存评论
public class blogComment {
	public String authorName;	// 作者姓名
	public String time;			// 发帖时间
	public String commentText;	// 评论内容
}
