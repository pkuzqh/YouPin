package Community;

public class blogText 
{
	public String text;
}
